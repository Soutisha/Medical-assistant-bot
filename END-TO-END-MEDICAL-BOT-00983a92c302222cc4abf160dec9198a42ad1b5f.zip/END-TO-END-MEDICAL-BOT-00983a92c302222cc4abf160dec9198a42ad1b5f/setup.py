from setuptools import find_packages,setup


setup(


    name="MEDICAL BOT GENERATIVE AI PROJECT",
    version='0.0.0',
    author='Animesh',
    author_email='animeshkumarkar24@gmail.com',
    packages=find_packages(),
    install_requires=[]
)